<?php 
include 'header.php';
?>


<!--<script>-->
<!--function goBack() {-->
<!--  window.history.back();-->
<!--}-->
<!--</script>-->

<div class="jumbotron text-center">
  <h1 class="display-3">Thank You!</h1>
  <p class="lead"><strong>Your Inquiry has been recived, We will be in touch with you shortly..

</strong></p>
  <hr>
  <p>
    Having trouble? <a href="contact.php">Contact us</a>
  </p>
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="index.php" role="button">Continue to homepage</a>
    <!--<a class="btn btn-primary btn-sm" onclick="goBack()" role="button">Back Page</a>-->
    
  </p>
</div>

<?php 
include 'footer.php';
?>