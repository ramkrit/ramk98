<?php include "header.php";

                include "admin/db.php";
                $idd=$_GET['id'];
                
                $sql1 = "SELECT * FROM sub_category  
                        WHERE sub_category='$idd' ";
                $query1 = mysqli_query($conn,$sql1);
                
                $roww = mysqli_fetch_array($query1);
                
                
    
    
    $sql = "SELECT * FROM image_gallery  
            WHERE category_id='$idd'
            Order BY id DESC";
    $query = mysqli_query($conn,$sql);
                


?>

<style>

    .customPagination, .paginacaoCursor{
			margin: 1px;
			padding: 5px 8px;
			color: #fff;
			background: grey;
			cursor: pointer;
			border-radius:3px;
			
		}
    

    .sttle{
       
        border-radius: 5px;
 
    }
    
</style>

        <div class="top-single-bkg " style="background-image:url('images/home/art-gallary.jpg');">
        		<div class="inner-desc">
        			<div class="container">
        					<h1 class="post-title single-post-title heading-4 font-weight-normal"><?php echo $roww['sub_category'];?></h1>
        			</div>
                </div>
        </div>
        
		<div class="page-holder custom-page-template page-full fullscreen-page clearfix" >
		
			<section class="section-holder">
				<div class="gallery-container">
					<div class="container">
						<div class="row gallery-holder gallery-grid3cols paginationTable">
                             <?php
                $s=1;
                while($row=mysqli_fetch_array($query) ){

            ?>
							<div class="col-sm-6 col-lg-4 gallery-post tableItem">
							    
							    <div class=" p-3 sttle d-flex align-items-center " style="border: 1px solid lightgrey;height: 350px;min-width: 350px;" > 
    								<a href="admin/image_gallery/<?php echo $row['image'];?>" class="lightbox" style="margin:0 auto;">
    								 <center>
    								     <img class="img-fluid" src="admin/image_gallery/<?php echo $row['image'];?>" alt="" title="Image <?php echo $s;?>" style="max-height:318px; display: block;box-shadow: 0 0 11px 0px #c3c2c2;"> 
    								</center>
    								</a>
							    
							    </div>
							    
							    <center><p class="pt-1"><b><?php echo $row['title'];?></b><br>
							    <?php echo $row['size'];?><br>
							    <?php echo $row['code'];?>
							    
							    
							    </p></center>
							</div>
							
				<?php 
				$s++;
                }
				?>
                    			
				
						</div>
						
						
						
						<div class="row mt-2">
						    
                            <div id="pagination-container" style="margin:0 auto; padding-top:28px;">
                                
                                <p class='paginacaoCursor' id="beforePagination">Previous</p>
                                <p class='paginacaoCursor' id="afterPagination">Next</p>
                                    
                             </div>
                    </div>	
						
					
					</div>
				</div>
			</section>
		</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script>$(document).ready(function(){

  var HZperPage = 12,//number of results per page
     HZwrapper = 'paginationTable',//wrapper class
     HZlines   = 'tableItem';//items class
     HZpaginationId ='pagination-container',//id of pagination container
     HZpaginationArrowsClass = 'paginacaoCursor',//set the class of pagi
     HZpaginationColorDefault =  'grey',//default color for the pagination numbers
     HZpaginationColorActive = '#e52628', //color when page is clicked
     HZpaginationCustomClass = 'customPagination'; //custom class for styling the pagination (css)
   

   /*-------------------------F/ AHMED HIJAZI -------------------------*/
   /*------------------------- HOPE YOU LIKE -------------------------*/


  function paginationShow(){if($("#"+HZpaginationId).children().length>8){var a=$(".activePagination").attr("data-valor");if(a>=4){var i=parseInt(a)-3,o=parseInt(a)+2;$(".paginacaoValor").hide(),exibir2=$(".paginacaoValor").slice(i,o).show()}else $(".paginacaoValor").hide(),exibir2=$(".paginacaoValor").slice(0,5).show()}}paginationShow(),$("#beforePagination").hide(),$("."+HZlines).hide();for(var tamanhotabela=$("."+HZwrapper).children().length,porPagina=HZperPage,paginas=Math.ceil(tamanhotabela/porPagina),i=1;i<=paginas;)$("#"+HZpaginationId).append("<p class='paginacaoValor "+HZpaginationCustomClass+"' data-valor="+i+">"+i+"</p>"),i++,$(".paginacaoValor").hide(),exibir2=$(".paginacaoValor").slice(0,5).show();$(".paginacaoValor:eq(0)").css("background",""+HZpaginationColorActive).addClass("activePagination");var exibir=$("."+HZlines).slice(0,porPagina).show();$(".paginacaoValor").on("click",function(){$(".paginacaoValor").css("background",""+HZpaginationColorDefault).removeClass("activePagination"),$(this).css("background",""+HZpaginationColorActive).addClass("activePagination");var a=$(this).attr("data-valor"),i=a*porPagina,o=i-porPagina;$("."+HZlines).hide(),exibir=$("."+HZlines).slice(o,i).show(),"1"===a?$("#beforePagination").hide():$("#beforePagination").show(),a===""+$(".paginacaoValor:last").attr("data-valor")?$("#afterPagination").hide():$("#afterPagination").show(),paginationShow()}),$(".paginacaoValor").last().after($("#afterPagination")),$("#beforePagination").on("click",function(){var a=$(".activePagination").attr("data-valor"),i=parseInt(a)-1;$("[data-valor="+i+"]").click(),paginationShow()}),$("#afterPagination").on("click",function(){var a=$(".activePagination").attr("data-valor"),i=parseInt(a)+1;$("[data-valor="+i+"]").click(),paginationShow()}),$(".paginacaoValor").css("float","left"),$("."+HZpaginationArrowsClass).css("float","left");
})</script>
	<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
	<script type="text/javascript" src="HZpagination.js"></script>

<?php include "footer.php";?>
