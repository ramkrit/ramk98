<?php include "header.php";?>
<style>
    .alignc {
    text-align: center;
    background-color: #eeeeee;
    padding: 40px 0px;
    }
    .mt-60{
        margin-top:60px;
    }
    
</style>
		<div class="top-single-bkg " style="background-image:url('images/home/about.jpg');">
			<div class="inner-desc">
				<div class="container">
					<h1 class="post-title single-post-title heading-4 font-weight-normal"> About Us</h1>
					<span class="post-subtitle page-subtitle"> We play with Colors</span>
				</div>
			</div>
		</div>
		<!-- /PAGE TOP -->
		<!-- PAGE CONTENT -->
		<div class="page-holder custom-page-template page-full fullscreen-page clearfix " >
		<!-- SECTION 1-->
		<section class="section-holder aligncm  ">
			<div class="container ">
				<div class="row ">
					<div class="col-lg-6 margin-bm54" style="margin-top:-12px;">
						<div class="margin-r54">
							<h2 class="section-title mb-2 heading">About Us</h2>
							<span style="font-weight: 500;font-size: 19px;color: #151515; margin-bottom:7px;display:block;">Your desire our creation...</span>
							
							<p class="text-justify">
							     <!--We deliver your inner smile with true happiness. <br>-->
                                Zero Art Creations started their work in <span style="letter-spacing:-1px;">India in 2012 and since then </span>
                                
                                <br> Unique hand Made art & craft products. Its founder, Nisha Sharma self taught artist is intensely involved with design as an art form. We have been creating to the needs of various clients in the field of Fine Arts.
                                <br><br>
                                In the fine arts, we started our journey creating Sketches  for various clients in Delhi, Indore, Kolkata, Mumbai. Subsequently, we ventured into catering to the needs of the art lover. We did acrylic, oil paintings and art frames for various organizations. We did fine art store in some malls & colleges in Delhi.
                                We are constantly working to maintain our superiority in terms of quality.<br><br>
                                We deliver excellence art products, art consultancy for our esteemed clients, we are among the best in the field with respect to art creation of various products, painting, portrait, drawing, illustration and crafts.
                                <br><br>
                               <b> Nisha Sharma, Zero Art Creations, Since 2012</b>
							</p>
							
							</div>
					</div>
					<div class="col-lg-6">
						<img class="img-fluid" src="images/pages/zero_02.jpg" alt="">
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</section>
		<!-- /SECTION 1-->
		<!-- SECTION 2-->
		<section class="section-holder alignc mb-0">
			<div class="container">
				<div class="row">
					<div class="col-lg-4">
						<div class="box-holder margin-bm54">
							<h3 class="box-title heading-4">Paintings</h3>
							<p>Painting is the practice of applying paint, pigment, color or other medium to a solid surface . </p>
						</div>
					</div>
					<!-- /col-lg-4 -->
					<div class="col-lg-4">
						<div class="box-holder margin-bm54">
							<h3 class="box-title heading-4">Portraits</h3>
							<p>
							A portrait is a painting, photograph, sculpture, or other artistic representation of a person, in which the face and its expression is predominant.    
							</p>
						</div>
					</div>
					<!-- /col-lg-4 -->	
					<div class="col-lg-4">
						<div class="box-holder">
							
							<h3 class="box-title heading-4">Drawings</h3>
							<p>Drawing is a form of visual art in which one uses various drawing instruments to mark paper or another two-dimensional medium. </p>
						</div>
					</div>
					
					<div class="col-lg-4 offset-md-2 mt-4">
						<div class="box-holder">
							
							<h3 class="box-title heading-4">Illustrations</h3>
							<p>An illustrator is an artist who creates two-dimensional images for various companies and industries, such as fashion design, 
							children's books, and advertising.</p>
						</div>
					</div>
					<div class="col-lg-4 mt-4">
						<div class="box-holder">
							
							<h3 class="box-title heading-4">Art & Crafts</h3>
							<p>A handicraft, sometimes more precisely expressed as artisanal handicraft or handmade, is any of a wide variety 
							of types of work where useful and decorative objects. </p>
						</div>
					</div>
					
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</section>
	
		</div>
		
<?php include "footer.php";?>