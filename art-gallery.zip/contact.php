<?php include"header.php";?>
<style>
    .fafago li a{
        color:#5d5e60;
        font-size:24px;
    }
</style>

		<div class="top-single-bkg " style="background-image:url('images/home/cont.jpg');">
			<div class="inner-desc">
				<div class="container">
					<h1 class=" heading-4 post-title single-post-title  font-weight-normal" >Contact Us</h1>
					<span class="post-subtitle page-subtitle">Contact us for more information</span>
				</div>
			</div>
		</div>
		<!-- /PAGE TOP -->
		<!-- PAGE CONTENT -->
		<div class="page-holder custom-page-template page-full fullscreen-page clearfix">
			<!-- SECTION 1-->
			<section class="section-holder">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 margin-bm54 aligncm">
							<div class="margin-r54">
								<h2 class="section-title margin-b32 heading">Contact Details</h2>
							 <div class="row">
							     <div class="col-lg-12">
							         <h5 class="heading-4"><i class="fa fa-map-marker pr-2" aria-hidden="true"></i>Address:</h5>
								<p>11A , Block E 3 , Molarband Ext , Badarpur ,South Delhi-110044</p>
								
							     </div>
							     <div class="col-lg-12">
							         <div class="row">
							             <div class="col-lg-6">
							                <h5 class="heading-4"><i class="fa fa-phone " aria-hidden="true"></i> Phone:</h5>
                								<p>+91 9667056026</p>
                								
                								<h5 class="heading-4"><i class="fa fa-envelope pr-2" aria-hidden="true"></i>Email:</h5>
                								<p><a href="mailto:zeroartcreations@gmail.com" style="color:#858585;">zeroartcreations@gmail.com</a><br>
                								    <a href="mailto:info@zeroartcreations.com" style="color:#858585;">info@zeroartcreations.com</a>
                								</p>
                								
                								
                								<ul class="social-media header-social-1  pt-2 fafago text-center text-lg-left">
                                    						<li><a class="social-facebook" href="https://www.facebook.com/zeroartcreations" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                    						<li><a class="social-instagram" href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                    						<li><a href="#" target="_blank"><i class="fab fa-pinterest"></i></a></li>
                                    						<li><a  href="https://www.youtube.com/channel/UChw24e8KZVbfkrm7qVkqPTQ" target="_blank"><i class="fab fa-youtube"></i></a></li>
                                    		    </ul>
                								 
							             </div>
							             <div class="col-lg-6 " style="padding: 60px 20px 0px 20px;">
							                 <img src="images/PAYTM.jpg" ><br>
							                 <h2 class="section-title  heading pt-5" style="font-size: 23px;text-align: center;">Ask to Scan this QR To Accept Money</h2>
							            </div>
							         </div>
							     </div>
							     
							 </div>
								
								
							</div>
						</div>
						<!-- /col-lg-6 -->	
						<div class="col-lg-6">
							<h2 class="section-title margin-b32 heading">Get In Touch</h2>
							<div id="contact-form-holder">
								<form method="post" action="mail.php">

									<div class="margin-b24">
										<input type="text" name="name" class="comm-field" placeholder="Name" />
									</div>
									<div class="margin-b24">
										<input type="text" name="email" class="comm-field" placeholder="Email" /></div>
									<div class="margin-b24">
									<input type="text" name="phone" class="comm-field" pattern="[6-9]{1}[0-9]{9}" maxlength="10"placeholder="Phone Number" /> </div>
									<div class="margin-b24">
										<textarea name="message" id="msg-contact" rows="5" placeholder="Message"></textarea>
									</div>
									
									<p><input type="submit" value="Send message" name="submit" id="submit"/></p>
								</form>
							</div>
							<!-- contact-form-holder-->
							<div id="output-contact"></div>
						</div>
						<!-- /col-lg-6 -->		
					</div>
					<!-- /row -->
				</div>
				<!-- /container -->
			</section>
			<!-- /SECTION 1-->
			<!-- SECTION 2-->
			<!--payment-->
			<!--<section class="section-holder">-->
			<!--    <div class="container">-->
			<!--        <div class="text-center">-->
			<!--            <h2 class="section-title pb-3 heading">Pay Now</h2>-->
			            
			<!--            <img src="images/WhatsApp Image 2020-11-04 at 4.00.44 PM.jpeg" style="width:450px;">-->
			<!--        </div>-->
			<!--    </div>-->
			<!--</section>-->
			<!--<section >-->
				<div class="gmaps">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3506.599624365355!2d77.31203491423253!3d28.49160188247366!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce71e8eb6032b%3A0x35ae02a490afd37!2s11A%2C%203%2C%20Block%20E1%2C%20Block%20E%2C%20Molar%20band%20Extension%2C%20Badarpur%2C%20New%20Delhi%2C%20Haryana%20110044!5e0!3m2!1sen!2sin!4v1602248498453!5m2!1sen!2sin"
                   height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
				</div>
			</section>
			<!-- /SECTION 2-->
		</div>
		<!-- page-content -->
		
<?php include"footer.php";?>