<style>

    .float{
	position:fixed;
	width:60px;
	height:60px;
	bottom:40px;
	right:40px;
	background-color:#25d366;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:30px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
}

    .my-float{
	margin-top:16px;
}
</style>


		
		<footer class="mt-0">
			<div class="container">
				<div class="footer-widgets">
					<div class="row" style="margin-bottom: -40px;">
						<div class="col-md-4">
							<div class="foo-block">
								<div class="widget widget-footer widget_text text-left">
									<h5 class="widgettitle heading-4 font-weight-normal">About Us</h5>
									<div class="">
										<p class="text-justify">
										    <span style="font-weight: 500;font-size: 19px;color: #fff; margin-bottom:7px;display:block;">Your desire our creation...</span>
											Zero Art Creations started their work in <span style="letter-spacing:-1px;">India in 2012 and since then </span>
                                
                               Unique hand Made art & craft products. Its founder, Nisha Sharma self taught artist is intensely involved 
                                with design as an art form. 
										</p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-2">
							<div class="foo-block foo-last">
								<div class="widget_text widget widget-footer widget_custom_html text-left ">
									<h5 class="widgettitle heading-4 font-weight-normal">Quick Links</h5>
									<div class="textwidget custom-html-widget ">
										<ul class="">
											<li> <a href="index.php">Home</a></li>
											<li><a href="about-us.php">About</a></li>
											<li><a href="sold-art-work.php">Sold Art Work</a></li>
											<li><a href="contact.php">Contact Us</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="foo-block foo-last">
								<div class="widget_text widget widget-footer widget_custom_html text-left ">
								    
								    <h5 class="widgettitle  heading-4 font-weight-normal">Art Gallery</h5>    
								    
									<div class="textwidget custom-html-widget">
									    <div class="container-fluid">
									        <div class="row">
									            <div class="col-4 p-0 pr-1  text-center " >
									                <img class="img-fluid" src="images/home/Painting_icon.jpg" alt="" style="width:100%;height:100%;">
									            </div>
									            <div class="col-4 p-0 pr-1 text-center">
									                <img class="img-fluid" src="images/home/Portrait_icon.jpg" alt="" style="width:100%;height:100%;">
									            </div>
									            <div class="col-4 p-0 pr-1 text-center">
									                <img class="img-fluid" src="images/home/Illustration_icon.jpg" alt="" style="width:100%;height:100%;">
									            </div>
									            <div class="col-4 p-0 pr-1 pt-lg-1  pt-1  text-center" >
									                <img class="img-fluid" src="images/home/T-Shirt_icon.jpg" alt="" style="width:100%;height:100%;">
									            </div>
									            <div class="col-4 p-0 pr-1 pt-lg-1  pt-1 text-center">
									                <img class="img-fluid" src="images/home/Digital caricature_icon.jpg" alt="" style="width:100%;height:100%;">
									            </div>
									            <div class="col-4 p-0 pr-1 pt-lg-1  pt-1 text-center">
									                <img class="img-fluid" src="images/home/Decoretive iteam_icon.jpg" alt="" style="width:100%;height:100%;">
									            </div>
									        </div>
									    </div>	
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="foo-block">
								<div class="widget widget-footer widget_text   ">
									<h5 class="widgettitle mt-lg-0 mt-4 heading-4 font-weight-normal text-lg-right text-left">Contact Us</h5>
									<div class="textwidget">
										<div class="textwidget text-lg-right text-left">
											 <p class="mb-1"> <i class="fa fa-map-marker" aria-hidden="true"></i> 11A , Block E 3 , Molarband Ext , Badarpur <br>South Delhi-110044</p>
											<p class="mb-1">
												<i class="fa fa-phone mr-2" aria-hidden="true"></i><a href="tel:+91 9667056026" class="text-white">+91 9667056026</a>
											</p>
											<p class="mb-1">
			                              
			                               <i class="fa fa-envelope mr-1" aria-hidden="true"></i> <a href="mailto:info@zeroartcreations.com" class="text-white">info@zeroartcreations.com</a><br>
			                                <i class="fa fa-envelope mr-1" aria-hidden="true"></i> <a href="mailto:zeroartcreations@gmail.com" class="text-white">zeroartcreations@gmail.com</a>
			                               <br>
			                               
			                            </p>
                    			         <ul class="social-media header-social-1 text-lg-right text-left pt-2 ml-0">
                    						<li><a class="social-facebook" href="https://www.facebook.com/zeroartcreations" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                    						
                    						<li><a class="social-instagram" href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                    						<li><a href="#" target="_blank"><i class="fab fa-pinterest"></i></a></li>
                    						<li><a  href="https://www.youtube.com/channel/UChw24e8KZVbfkrm7qVkqPTQ" target="_blank"><i class="fab fa-youtube"></i></a></li>
                    					
                    					
                    					</ul>
                    					</div>
									</div>
								</div>
							</div>
						</div>
						
					</div>
				</div>
				
			</div>
			<div class="container-fluid" style="border-top: 1px solid #fff;">
			    <div class="container">
				<div class="row">
					<div class="col-lg-6 text-lg-left text-center">
							<p class="mt-3">© Copyright 2020 Zero Art Creations. All Rights Reserved</p>
						
					</div>
					<div class="col-lg-6 text-lg-right text-center ">
                    	 <p class="mt-3">
                    	 	Design By <a href="https://www.sbbjitsolutions.com/" target="_blank">SBBJ IT SOLUTIONS</a>
                    	 </p>
                </div>  
				</div>
				</div>
				</div>
			</div>
		</footer>
		<!-- FOOTER -->
		<div class="scrollup">
			<a class="scrolltop" href="#">
			<i class="fa fa-chevron-up"></i>
			</a>
		</div>
		<!-- JS --> 
		<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src='js/jquery.js'></script>
		<script src='js/jquery-migrate.min.js'></script>
		<script src='css/bootstrap/js/popper.js'></script>
		<script src='css/bootstrap/js/bootstrap.js'></script>
		<script src='js/easing.js'></script>
		<script src='js/fitvids.js'></script>
		<script src='js/owl-carousel/owl.carousel.js'></script>
		<script src='js/isotope.js'></script>
		<script src='js/simple-lightbox.js'></script>
		<!-- MAIN JS -->
		<script src='js/init.js'></script>
		<!-- CONTAT FORM JS -->
		<script src='js/jquery.form.min.js'></script>
		<script src='js/contactform.js'></script>
	</body>

</html>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<a href="https://api.whatsapp.com/send?phone=91 9667056026 &text= " class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>