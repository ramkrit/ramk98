<?php
    $nameErr = $emailErr = $phoneErr = $queryErr  = $invalid = $success = "";
    $name  = $email = $phone = $query = "";
    if(isset($_POST['submit'])){
        
        if(empty($_POST['name'])){
           	$nameErr = "Name is required";
        }else{
       	    // check if name only contains letters and whitespace
            if (!preg_match("/^[a-zA-Z ]*$/",$_POST['name'])) {
              $nameErr = "Only letters and white space allowed"; 
            }else{
                $name = live_query(ucfirst($_POST['name']));
            }
        }
        
        
        
        if(empty($_POST['email'])){
           	$emailErr = "Email is required";
        }else{
       	    // check if e-mail address is well-formed
            if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
              $emailErr = "Invalid email format"; 
            }else{
                $email = live_query($_POST['email']);
            }
        }
        
        if(empty($_POST['phone'])){
           	$phoneErr = "Phone is required";
        }else{
       	    // check if e-mail address is well-formed
            if (!is_numeric($_POST['phone'])) {
              $phoneErr = "Only digit allowed"; 
            }elseif (!preg_match("/^[6-9]\d{9}$/",$_POST['phone'])) {
              $phoneErr = "Invalid phone number";
            }else{
                $phone = live_query($_POST['phone']);
            }
        }
     
        if(empty($_POST['message'])){
           	$queryErr = "Message is required";
        }else{
            $query = live_query(ucfirst($_POST['message']));
        }
        
        if(!empty($name) && !empty($email) && !empty($phone) && !empty($query)){
            $to = "zeroartcreations@gmail.com";
            $subject = $name." Wants To contact you";
            $text = "Name:-".$name."\n"."Phone No.:-".$phone."\n"."E-mail:-".$email."\n"."Message:-".$query;
            $from = "From: ".$email;
            if(mail($to,$subject,$text,$from)){
                header("location:thank-you.php");
            }else{
                $invalid = "Something Went Wrong</script>";   
            }
        }
    }
                        
    function live_query($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
    if($nameErr != ""  || $emailErr != "" || $phoneErr != "" || $queryErr != "" || $invalid != "" || $success != ""){
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Zero Art Creations</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <center><h2>Contact Mail</h2></center>
    <?php
        if($nameErr != ""){
    ?>
      <div class="alert alert-danger">
        <strong><?=$nameErr?>!</strong>
      </div>
      <?php
        }
     
    ?>
      
      <?php
        
        if($emailErr != ""){
    ?>
      <div class="alert alert-danger">
        <strong><?=$emailErr?>!</strong>
      </div>
    <?php
        }
        if($phoneErr != ""){
    ?>
      <div class="alert alert-danger">
        <strong><?=$phoneErr?>!</strong>
      </div>
    <?php
        }
      if($queryErr != ""){
    ?>
      <div class="alert alert-danger">
        <strong><?=$queryErr?>!</strong>
      </div>
    <?php
        }
        if($invalid != ""){
    ?>
      <div class="alert alert-danger">
        <strong><?=$invalid?>!</strong>
      </div>
    <?php
        }   
        if($success != ""){
    ?>
    <div class="alert alert-success">
        <strong><?=$success?>!</strong>
      </div>
      <?php
        }
      ?>
</div>

</body>
</html>
<script>
    setInterval(function(){
        window.location='contact.php';
    }, 2000);
</script>
<?php
    }
?>