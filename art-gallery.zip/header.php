<?php 
 include "admin/oops.php";
$obj=new Database();

?>

<!DOCTYPE html>
<html lang="en-US">
<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Zero Art Creations </title>
		<!-- Google Fonts -->
		<link rel='stylesheet' id='gleam-font-css'  href='https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700,700i%7CCormorant:400,400i,500,600,700,700i' type='text/css' media='all' />
		<!-- Bootstrap CSS -->
		<link rel='stylesheet' id='bootstrap-css'  href='css/bootstrap/css/bootstrap.css' type='text/css' media='all' />
		<!-- Font Awesome Icons CSS -->
		<link rel='stylesheet' id='font-awesome'  href='css/fontawesome/css/all.css' type='text/css' media='all' />
		<!-- Owl Carousel -->
		<link rel='stylesheet' id='owl-carousel'  href='js/owl-carousel/owl.carousel.css' type='text/css' media='all' />
		<!-- Main CSS File -->
		<link rel='stylesheet' id='gleam-style-css'  href='style.css' type='text/css' media='all' />
		<!-- favicons -->
		<link rel="icon" href="images/icons/favicon (3).png" sizes="32x32" />
		<link rel="icon" href="images/icons/favicon (3).png" sizes="192x192" />
<style>
    ::selection {
  color:#fff;
  background: #e62627;
}

  /*Styling preloader*/
      .preloader{
          /*
          Making the preloader floating over other elements.
          The preloader is visible by default. 
          */
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: 1000;
      }
      
       .pm{
          /*
          Making the preloader floating over other elements.
          The preloader is visible by default. 
          */
          position: fixed;
          top: 50%;
          left: 50%;
         
      }
      .animate09{
          animation :preloader 6s infinite linear;
      }
      @keyframes preloader{
            0% {transform:rotate(0deg)}
           100% {transform:rotate(359deg)}
      }
      @media only screen and (max-width: 600px) {
	   .pm{
          
          position: fixed;
          top: 40%;
          left: 40%;
         
      }
      }
</style>
 
 
 
 
 
 
 
 
	</head>
	<body class="home">
<div class="preloader" style="background-color:white;"><span class="preloader-js "><img class="pm animate09" src="images/favicon.png"></span></div>
 


		<div class="menu-mask"></div>
		<!-- MOBILE MENU HOLDER -->
		<div class="mobile-menu-holder">
			<div class="modal-menu-container">
				<div class="exit-mobile"> <span class="icon-bar1"></span> <span class="icon-bar2"></span></div>
				<ul class="menu-mobile">
					<li class="menu-item  ">
						<a href="index.php">Home</a>						
					</li>
					<li class="menu-item ">
						<a href="about-us.php">About Us</a>
					</li>
					
					<li class="menu-item menu-item-has-children">
						<a href="portfolio-grid-3cols-fullscreen.html">Art Gallery</a>
						<ul class="sub-menu">
								    
							<li class="menu-item menu-item-has-children">
								<a href="javascript:void(0)">Paintings</a>
							<ul class="sub-menu">
								     

    						    <?php
    						        $obj->select('sub_category', "*", null, ' category="Paintings"', null, null);
    						        // echo "<pre>";
    						        // print_r($obj->showResult());
    						        // echo "</pre>";

    						        $sub_category_array=$obj->showResult();
    						        foreach ($sub_category_array as $key => $sub_categoryrrp) {
    						        foreach ($sub_categoryrrp as list('sub_category' => $sub_category)) {
    						        	?>

    						        <li class="menu-item">
										<a href="art-gallery.php?id=<?php echo $sub_category;?>"><?php echo $sub_category;?></a>
									</li>
   						        	<?php
    						        }
    						    	}
    						        ?>


						        						
								</ul>
							</li>
							<li class="menu-item menu-item-has-children">
								<a href="javascript:void(0)">Portraits</a>
								<ul class="sub-menu">
									<?php
    						        $obj->select('sub_category', "*", null, ' category="Portraits"', null, null);
    						        
    						        $sub_category_array=$obj->showResult();
    						        foreach ($sub_category_array as $key => $sub_categoryrrp) {
    						        foreach ($sub_categoryrrp as list('sub_category' => $sub_category)) {
    						        	?>

    						        <li class="menu-item">
										<a href="art-gallery.php?id=<?php echo $sub_category;?>"><?php echo $sub_category;?></a>
									</li>
   						        	<?php
    						        }
    						    	}
    						        ?>
						        
								</ul>
							</li>
							<li class="menu-item menu-item-has-children">
								<a href="javascript:void(0)">Drawings</a>
								<ul class="sub-menu">
									<?php
    						        $obj->select('sub_category', "*", null, ' category="Drawings"', null, null);
    						        
    						        $sub_category_array=$obj->showResult();
    						        foreach ($sub_category_array as $key => $sub_categoryrrp) {
    						        foreach ($sub_categoryrrp as list('sub_category' => $sub_category)) {
    						        	?>

    						        <li class="menu-item">
										<a href="art-gallery.php?id=<?php echo $sub_category;?>"><?php echo $sub_category;?></a>
									</li>
   						        	<?php
    						        }
    						    	}
    						        ?>
						        </ul>
							</li>
							<li class="menu-item menu-item-has-children">
								<a href="javascript:void(0)">Illustrations</a>
								<ul class="sub-menu">
									<?php
    						        $obj->select('sub_category', "*", null, ' category="Illustrations"', null, null);
    						        
    						        $sub_category_array=$obj->showResult();
    						        foreach ($sub_category_array as $key => $sub_categoryrrp) {
    						        foreach ($sub_categoryrrp as list('sub_category' => $sub_category)) {
    						        	?>

    						        <li class="menu-item">
										<a href="art-gallery.php?id=<?php echo $sub_category;?>"><?php echo $sub_category;?></a>
									</li>
   						        	<?php
    						        }
    						    	}
    						        ?>
						        	</ul>
							</li>
							<li class="menu-item menu-item-has-children">
								<a href="javascript:void(0)">Art & Crafts</a>
							
									<ul class="sub-menu">
										<?php
    						        $obj->select('sub_category', "*", null, ' category="Art & Crafts"', null, null);
    						        
    						        $sub_category_array=$obj->showResult();
    						        foreach ($sub_category_array as $key => $sub_categoryrrp) {
    						        foreach ($sub_categoryrrp as list('sub_category' => $sub_category)) {
    						        	?>

    						        <li class="menu-item">
										<a href="art-gallery.php?id=<?php echo $sub_category;?>"><?php echo $sub_category;?></a>
									</li>
   						        	<?php
    						        }
    						    	}
    						        ?>
						        								</ul>
							</li>
						</ul>
					</li>
					<li class="menu-item"><a href="sold-art-work.php">Sold Art Work</a></li>
					<li class="menu-item"><a href="contact.php">Contact Us</a></li>
				</ul>
			</div>
			
		</div>
		<!-- /MOBILE MENU HOLDER -->
		<!-- HEADER -->
		<header class="main-header header-1">
			<div class="container">
				<div class="header-container">
					<div class="logo logo-1 logo-white"><a href="index.php"><img class="img-fluid" src="images/logo (4).png" alt="Gleam"></a></div>
					<div class="logo logo-1 logo-dark"><a href="index.php"><img class="img-fluid " src="images/logo (4).png" alt="Gleam"></a></div>
					<nav class="nav-holder nav-holder-1">
						<ul class="menu-nav">
							<li class="menu-item menu-item-has-children ">
								<a href="index.php">Home</a>
							</li>
							<li class="menu-item menu-item-has-children">
								<a href="about-us.php">About Us</a>								
							</li>
							<li class="menu-item menu-item-has-children">
								<a href="javascript:void(0)">Art Gallery</a>
								<ul class="sub-menu">
								    
							<li class="menu-item menu-item-has-children">
								<a href="javascript:void(0)">Paintings</a>
								<ul class="sub-menu">
								     

    						    <?php
    						        $obj->select('sub_category', "*", null, ' category="Paintings"', null, null);
    						        // echo "<pre>";
    						        // print_r($obj->showResult());
    						        // echo "</pre>";

    						        $sub_category_array=$obj->showResult();
    						        foreach ($sub_category_array as $key => $sub_categoryrrp) {
    						        foreach ($sub_categoryrrp as list('sub_category' => $sub_category)) {
    						        	?>

    						        <li class="menu-item">
										<a href="art-gallery.php?id=<?php echo $sub_category;?>"><?php echo $sub_category;?></a>
									</li>
   						        	<?php
    						        }
    						    	}
    						        ?>


						        						
								</ul>
							</li>
							<li class="menu-item menu-item-has-children">
								<a href="javascript:void(0)">Portraits</a>
								<ul class="sub-menu">
									<?php
    						        $obj->select('sub_category', "*", null, ' category="Portraits"', null, null);
    						        
    						        $sub_category_array=$obj->showResult();
    						        foreach ($sub_category_array as $key => $sub_categoryrrp) {
    						        foreach ($sub_categoryrrp as list('sub_category' => $sub_category)) {
    						        	?>

    						        <li class="menu-item">
										<a href="art-gallery.php?id=<?php echo $sub_category;?>"><?php echo $sub_category;?></a>
									</li>
   						        	<?php
    						        }
    						    	}
    						        ?>
						        
								</ul>
							</li>
							<li class="menu-item menu-item-has-children">
								<a href="javascript:void(0)">Drawings</a>
								<ul class="sub-menu">
									<?php
    						        $obj->select('sub_category', "*", null, ' category="Drawings"', null, null);
    						        
    						        $sub_category_array=$obj->showResult();
    						        foreach ($sub_category_array as $key => $sub_categoryrrp) {
    						        foreach ($sub_categoryrrp as list('sub_category' => $sub_category)) {
    						        	?>

    						        <li class="menu-item">
										<a href="art-gallery.php?id=<?php echo $sub_category;?>"><?php echo $sub_category;?></a>
									</li>
   						        	<?php
    						        }
    						    	}
    						        ?>
						        </ul>
							</li>
							<li class="menu-item menu-item-has-children">
								<a href="javascript:void(0)">Illustrations</a>
								<ul class="sub-menu">
									<?php
    						        $obj->select('sub_category', "*", null, ' category="Illustrations"', null, null);
    						        
    						        $sub_category_array=$obj->showResult();
    						        foreach ($sub_category_array as $key => $sub_categoryrrp) {
    						        foreach ($sub_categoryrrp as list('sub_category' => $sub_category)) {
    						        	?>

    						        <li class="menu-item">
										<a href="art-gallery.php?id=<?php echo $sub_category;?>"><?php echo $sub_category;?></a>
									</li>
   						        	<?php
    						        }
    						    	}
    						        ?>
						        	</ul>
							</li>
							<li class="menu-item menu-item-has-children">
								<a href="javascript:void(0)">Art & Crafts</a>
							
									<ul class="sub-menu">
										<?php
    						        $obj->select('sub_category', "*", null, ' category="Art & Crafts"', null, null);
    						        
    						        $sub_category_array=$obj->showResult();
    						        foreach ($sub_category_array as $key => $sub_categoryrrp) {
    						        foreach ($sub_categoryrrp as list('sub_category' => $sub_category)) {
    						        	?>

    						        <li class="menu-item">
										<a href="art-gallery.php?id=<?php echo $sub_category;?>"><?php echo $sub_category;?></a>
									</li>
   						        	<?php
    						        }
    						    	}
    						        ?>
						        								</ul>
							</li>
						</ul>
							</li>
							<li class="menu-item"><a href="sold-art-work.php">Sold Art Work</a></li>
							<li class="menu-item"><a href="contact.php">Contact Us</a></li>
						</ul>
					</nav>
					<div class="nav-button-holder"> <button type="button" class="nav-button"> <span class="icon-bar"></span> </button></div>
					
				</div>
			</div>
		</header>
		
		<script>
    //after window is loaded completely 
    window.onload = function(){
        //hide the preloader
        document.querySelector(".preloader").style.display = "none";
    }
</script>