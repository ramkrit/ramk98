<?php include"header.php"?>
<style>
    .sttle{
    
    text-align: center;
    }
    .shadow09{
        box-shadow: 0 0 10px -5px black;
        border-radius: 5px;
    }
    
    .active .img-animte{
        
  animation-name: ram;
  animation-duration: 8s;
  animation-iteration-count: infinite;
  animation-timing-function:linear;
    
    
		}

	@keyframes ram{
		0%{transform: scale(1.3);opacity:0.6;}
		5%{opacity:1;}
		100%{transform: scale(1);}	
	}
	.text-animte{
	  position:absolute;
	  top:2px;
	  left:125px;
	}
	
	.text-animte h4{
	    line-height:35px; 
	    font-size:29px;
	    letter-spacing:1px;
	}
	.active .text-animte{
	    animation:text 2.5s linear, text2 8s linear;
	    
	}
	
	@keyframes text{    
	    0%{
	       top:100px;
	    }
	    
	    100%{
	       top:2px ;
	    }
	}
	
		@keyframes text2{    
	    0%{
	      opacity:1;
	    }
	    
	    92%{
	       opacity:1;
	    }
	    100%{
	       opacity:0;
	    }
	}
	.whater-mark{
	    position:absolute;
	    top:25px;
	    bottom:20px;
	    
	}
	@media only screen and (max-width: 600px) {
	    .owl-carousel .owl-item img {
	        
    width: 200%;
	    }
 .whater-mark{
	    
    left: -179px;
}
.text-animte h4{
	    line-height:20px; 
	    font-size:16px;
	    letter-spacing:1px;
	}

.text-animte {
    left: 0px;
    top:19px;

	}
	.whater-mark{
	    position:absolute;
	    top:55px;
	    
	}
	@keyframes text{    
	    0%{
	       top:100px;
	    }
	    100%{
	       top:19px ;
	    }
	}
} 
	
</style>

		<!-- HOME SLIDER -->
		<div class="slider-container">
			<div class="owl-carousel owl-theme home-slider">
				<div class="slider-post slider-item-box-bkg">
					<div class="slider-img img-animte" style="background-image:url('images/home/Slide_01.jpg');">
					    
					</div>
					<img src="images/home/Slide_01A_Water_Mark.png" class="whater-mark" class="img-fluid">
					<div class="container slider-caption">
						<div class="slider-text text-animte">
						    
							<h4 class="heading-4 font-weight-normal text-white" >Your desire <br>&nbsp;&nbsp;&nbsp;&nbsp;Our creation...</h4>
							
						</div>
					</div>
					<!--slider-caption-->
				</div>
				<div class="slider-post slider-item-box-bkg">
					<div class="slider-img img-animte" style="background-image:url('images/home/home-banner2.jpg');">
					    
					</div>
					<!--<img src="images/home/Slide_01A_Water_Mark.png" class="whater-mark">-->
					<div class="container slider-caption">
						<div class="slider-text text-animte">
						    
							<h4 class="heading-4 font-weight-normal text-white" >Your desire <br>&nbsp;&nbsp;&nbsp;&nbsp;Our creation...</h4>
							
						</div>
					</div>
				</div>
				<div class="slider-post slider-item-box-bkg">
					<div class="slider-img img-animte" style="background-image:url('images/home/home-banner3.jpg');">
					    
					</div>
					<!--<img src="images/home/Slide_01A_Water_Mark.png" class="whater-mark">-->
					<div class="container slider-caption">
						<div class="slider-text text-animte">
						    
							<h4 class="heading-4 font-weight-normal text-white" >Your desire <br>&nbsp;&nbsp;&nbsp;&nbsp;Our creation...</h4>
							
						</div>
					</div>
				</div>
				
			</div>
		</div>
		
		
	<div class="page-holder custom-page-template page-full fullscreen-page clearfix">	
		<section class="section-holder aligncm ">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 margin-bm54" style="margin-top:-12px;">
						<div class="margin-r54">
							<h2 class="section-title mb-2 heading">About Us</h2>
							    	<span style="font-weight: 500;font-size: 19px;color: #151515; margin-bottom:7px;display:block;">Your desire our creation...</span>
							<p class="text-justify">
							    
							   Zero Art Creations started their work in <span style="letter-spacing:-1px;">India in 2012 and since then </span>
                                
                                <br> Unique hand Made art & craft products. Its founder, Nisha Sharma self taught artist is intensely involved with design as an art form. We have been creating to the needs of various clients in the field of Fine Arts.
                                <br><br>
                                In the fine arts, we started our journey creating Sketches  for various clients in Delhi, Indore, Kolkata, Mumbai. Subsequently, we ventured into catering to the needs of the art lover. We did acrylic, oil paintings and art 
                                frames for various organization. We did fine art store in some malls & colleges in Delhi.
                                <br>
							</p>
							<a href="about-us.php" class="read-more white-btn mt-3">Read More..</a>
							</div>
					</div>
					<div class="col-lg-6">
						<img class="img-fluid" src="images/pages/zero_02.jpg" alt="">
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</section>
	</div>	
		
		
	 <!--gallery click and get big image-->
		<div class="page-holder custom-page-template page-full fullscreen-page clearfix">
			<section class="section-holder margin-b72 aligncm">
				
			</section>
			<section class="section-holder">
				<div class="gallery-container">
					<div class="container">
					    <center><h2 class=" heading" style="margin-bottom:75px;">Our Work</h2></center>
						<div class="row gallery-holder gallery-grid3cols">
						    
                            
							<div class="col-sm-6 col-lg-3 gallery-post ">
							    <div class=" p-1 sttle"> 
								<a href="images/home/IMG_20200311_085354 (2).jpg" class="lightbox" title="">
								 <img class="img-fluid shadow09" src="images/home/IMG_20200311_085354 (2).jpg" alt="" title="Image 1" > 
								</a>
							<center>	<p></p></center>
							    </div>
							</div>
							
							<div class="col-sm-6 col-lg-3 gallery-post ">
							    <div class=" p-1 sttle"> 
								<a href="images/home/E_IMG_20200805_085954.jpg" class="lightbox" title="">
								 <img class="img-fluid shadow09" src="images/home/E_IMG_20200805_085954.jpg" alt="" title="Image 2" > 
								</a>
							<center>	<p></p></center>
							    </div>
							</div>
							
							
							<div class="col-sm-6 col-lg-3 gallery-post ">
							    <div class=" p-1 sttle"> 
								<a href="images/home/IMG_20200910_082246.jpg" class="lightbox" title="">
								 <img class="img-fluid shadow09" src="images/home/IMG_20200910_082246.jpg" alt="" title="Image 3" > 
								</a>
							<center>	<p></p></center>
							    </div>
							</div>
							
							<div class="col-sm-6 col-lg-3 gallery-post ">
							    <div class=" p-1 sttle"> 
								<a href="images/home/IMG_20200910_082257_E.jpg" class="lightbox" title="">
								 <img class="img-fluid shadow09" src="images/home/IMG_20200910_082257_E.jpg" alt="" title="Image 4" > 
								</a>
							<center>	<p></p></center>
							    </div>
							</div>
							<div class="col-sm-6 col-lg-3 gallery-post ">
							    <div class=" p-1 sttle"> 
								<a href="images/home/IMG_20200910_082324_E.jpg" class="lightbox" title="">
								 <img class="img-fluid shadow09" src="images/home/IMG_20200910_082324_E.jpg" alt="" title="Image 5" > 
								</a>
							<center>	<p></p></center>
							    </div>
							</div>
							<div class="col-sm-6 col-lg-3 gallery-post ">
							    <div class=" p-1 sttle"> 
								<a href="images/home/IMG_20200910_082346_E.jpg" class="lightbox" title="">
								 <img class="img-fluid shadow09" src="images/home/IMG_20200910_082346_E.jpg" alt="" title="Image 6" > 
								</a>
							<center>	<p></p></center>
							    </div>
							</div>
							<div class="col-sm-6 col-lg-3 gallery-post ">
							    <div class=" p-1 sttle"> 
								<a href="images/home/WhatsApp Image 2020-09-24 at 4.09.29 AM.jpg" class="lightbox" title="">
								 <img class="img-fluid shadow09" src="images/home/WhatsApp Image 2020-09-24 at 4.09.29 AM.jpg" alt="" title="Image 7" > 
								</a>
							<center>	<p></p></center>
							    </div>
							</div>
							<div class="col-sm-6 col-lg-3 gallery-post ">
							    <div class=" p-1 sttle"> 
								<a href="images/home/artimg4.png" class="lightbox" title="">
								 <img class="img-fluid shadow09" src="images/home/artimg4.png" alt="" title="Image 8" > 
								</a>
							<center>	<p></p></center>
							    </div>
							</div>
							
							
				
							</div>
					</div>
				</div>
				
			</section>
			
		</div>
		
		
		
		<div class="page-holder custom-page-template page-full fullscreen-page home-page-content clearfix">
			
			<section class="parallax section-holder margin-none" style="background-image:url('images/home/info.jpg');">
				<div class="container parallax-content alignc">
					<div class="row">
						<div class="col-lg-10 offset-lg-1">
							<h2 class="section-title white margin-b32 heading">Your Desire Our Creation...</h2>
							<a href="contact.php" class="read-more white-btn">Contact Us Today</a>
						</div>
					</div>
				</div>
			</section>
			
		</div>
	
		
<?php include"footer.php"?>